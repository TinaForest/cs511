Dear teaching assistant,
 My name is Yunfei Tang. I think that there is something wrong with the letters.txt. 
 The real number of valid characters should be file.length()-2 since there are both space and newline characters in the file. 
 But I still followed the instruction demonstrated in the code. 
 I set the character number as file.length()-1 and deleted the space character in the letters.txt file.